%{
Dataset: BCIC III IV a
% 118 channels
% sampling rate 100 hz
% 2 class

Using 30 Channels
startEpoch = 0.5;   %start at second 0.5
endEpoch   = 3.5;   %end at second 3
Feature Extraction: CSP
Classifier: SVM and LDA
%}

%%
for all_channel=4:118 % Number of channel
    
addpath('\data'); %Put the downloaded in this folder
addpath('\true label'); %Put the true label in this folder

%% Load Dataset
load data_set_IVa_aa;
%% Load true labels    
load true_labels_aa;


cnt=0.1*double(cnt);

EEG_signal=cnt(:,:);
[org_row,org_col]=size(EEG_signal);
original_signal(org_row,org_col)=zeros();
original_signal=EEG_signal;
%% variance 
pos = mrk.pos;
fs= nfo.fs;   %sampling rate
class_label= true_y;
trials_number = length(class_label);  %length of class label
i1=0.5*fs;  %start Epoch
i2=3*fs;  %End Epoch
for i = 1:trials_number
	prd1 = pos(i)+i1:(pos(i) + i2 - 1); 
	sig1 = EEG_signal(prd1, :);
    Make_3D_Data(:,:,i) = sig1;
    
end

%% Shanon Entropy
 for j=1:trials_number
     for jj=1:118
    var_original_signal(j,jj)=entropy(Make_3D_Data(:,jj,j));
 
     end
 end

 entropy_original_signal=mean(var_original_signal);
 [B1,I1]=sort(entropy_original_signal,'descend');
 original_signal=EEG_signal(:,I1(1:all_channel)); 
 
 aa=nfo.clab(:,1:59);
 %
class_label= true_y;
fs= nfo.fs;   %sampling rate
pos = mrk.pos;

c=250; %no of sample
[~,channel]=size(original_signal); % no of channel


Fullband_filtered_signal=zeros(c,channel,trials_number);   %zeros(sample,channel,no of trial)
Suband1_filtered_signal=zeros(c,channel,trials_number); 
Suband2_filtered_signal=zeros(c,channel,trials_number); 
Suband3_filtered_signal=zeros(c,channel,trials_number); 

%% Data extraction Start

M = size(original_signal, 2);
trials_number = length(class_label);  %length of class label

i1=0.5*fs;  %start Epoch
i2=3*fs;  %End Epoch

for i = 1:trials_number
	prd1 = pos(i)+i1:(pos(i) + i2 - 1); 
	sig1 = original_signal(prd1, :); % extract each trial from dataset and kept into sig1 variable
	

%% Data extraction end

%Filtering Start   
%%.............Fullband-[8 35]  %............... %%
freqband1 = [8 35];
order=5;  %order=5
[b1,a1] = butter(order, freqband1/(fs/2), 'bandpass');
Fullband_filtered_signal(:,:,i) = filtfilt(b1,a1,sig1);

%%.............Subband 1-[8 13]  %............... %%
freqband2 = [8 13];
order=5;  %order=5
[b2,a2] = butter(order, freqband2/(fs/2), 'bandpass');
Suband1_filtered_signal(:,:,i) = filtfilt(b2,a2,sig1);

	%%.............Suband 2-[13 22]  %............... %%
freqband3 = [13 22];
order=5;  %order=5
[b3,a3] = butter(order, freqband3/(fs/2), 'bandpass');
Suband2_filtered_signal(:,:,i) = filtfilt(b3,a3,sig1);

	%%.............Suband 3-[22 35]  %............... %%
freqband4 = [22 35];
order=5;  %order=5
[b4,a4] = butter(order, freqband4/(fs/2), 'bandpass');
Suband3_filtered_signal(:,:,i) = filtfilt(b4,a4,sig1);
%Filtering End 
end

% extract class label index 
class1_label_index = find( class_label == 1 );
class2_label_index= find( class_label == 2 );

% separate class 1 and class 2 signal from Fullband 
Class1_Fullband = Fullband_filtered_signal(:,:,class1_label_index);
Class1_Fullband=permute(Class1_Fullband,[2,1,3]); %permute dimension
Class2_Fullband = Fullband_filtered_signal(:,:,class2_label_index);
Class2_Fullband=permute(Class2_Fullband,[2,1,3]); %permute dimension

% separate class 1 and class 2 signal from Subband 1
Class1_Subband1 = Suband1_filtered_signal(:,:,class1_label_index);
Class1_Subband1=permute(Class1_Subband1,[2,1,3]); %permute dimension
Class2_Subband1 = Suband1_filtered_signal(:,:,class2_label_index);
Class2_Subband1=permute(Class2_Subband1,[2,1,3]); %permute dimension

% separate class 1 and class 2 signal from Subband 2 
Class1_Subband2 = Suband2_filtered_signal(:,:,class1_label_index);
Class1_Subband2=permute(Class1_Subband2,[2,1,3]); %permute dimension
Class2_Subband2 = Suband2_filtered_signal(:,:,class2_label_index);
Class2_Subband2=permute(Class2_Subband2,[2,1,3]); %permute dimension

% separate class 1 and class 2 signal from from Subband 3
Class1_Subband3 = Suband3_filtered_signal(:,:,class1_label_index);
Class1_Subband3=permute(Class1_Subband3,[2,1,3]); %permute dimension
Class2_Subband3 = Suband3_filtered_signal(:,:,class2_label_index);
Class2_Subband3=permute(Class2_Subband3,[2,1,3]); %permute dimension

Fullband_filtered_signal=permute(Fullband_filtered_signal,[2,1,3]);
Suband1_filtered_signal=permute(Suband1_filtered_signal,[2,1,3]);
Suband2_filtered_signal=permute(Suband2_filtered_signal,[2,1,3]);
Suband3_filtered_signal=permute(Suband3_filtered_signal,[2,1,3]);

%%
Fullband_signal=cat(3,Class1_Fullband,Class2_Fullband); %concat class 1 and class 2
Subband1_signal=cat(3,Class1_Subband1,Class2_Subband1); %concat class 1 and class 2
Subband2_signal=cat(3,Class1_Subband2,Class2_Subband2); %concat class 1 and class 2
Subband3_signal=cat(3,Class1_Subband3,Class2_Subband3); %concat class 1 and class 2
groups(1,1:140)=ones();
groups(1,141:280)=zeros();
groups=groups';

[ch,~,~]=size(Class1_Fullband); %number of channel
ts=250; % Sample Point [start epoch 0.5-3 end epoch = 250]
%% Cross Validation usning KFold
no_of_fold=5;  %define no of total folding
indices = crossvalind('Kfold',groups,no_of_fold);
iteration=10; %number of iteration
ANN_Acc=zeros(1,iteration);
lda_acc1=zeros(1,no_of_fold);
Ann_c=zeros(1,no_of_fold);
fitacc=zeros(1,no_of_fold);
svmaccu=zeros(1,iteration);
LDAaccu=zeros(1,iteration);

for ii=1:iteration
for qq = 1:no_of_fold
        %% create train and test data set
        testSet = (indices == qq); trainSet = ~testSet;
        FullBand_train_data=Fullband_signal(:,:,trainSet);  % FullBand Train Dataset
        SubBand_1_train_data=Subband1_signal(:,:,trainSet);   % SubBand 1 Train Dataset 
        SubBand_2_train_data=Subband2_signal(:,:,trainSet);  % SubBand 2 Train Dataset
        SubBand_3_train_data=Subband3_signal(:,:,trainSet);  % SubBand 3 Train Dataset
        groups_data_train=groups(trainSet,:);  % Train Labels
        groups_data_test=groups(testSet,:);  % Test labels

        %% Divide train set into 2 classes(left+right)
        left_data_set=ismember(groups_data_train,1);
        right_data_set=ismember(groups_data_train,0);

        sum_left_train=sum(left_data_set);
        sum_right_train=sum(right_data_set);
        
        %For Fullband
        class1_left_FullBand=FullBand_train_data(:,:,left_data_set);
        class2_right_FullBand=FullBand_train_data(:,:,right_data_set);
        
        %For subband1
        class1_left_Subband1=SubBand_1_train_data(:,:,left_data_set);
        class2_right_Subband1=SubBand_1_train_data(:,:,right_data_set);
        %For subband2
        class1_left_Subband2=SubBand_2_train_data(:,:,left_data_set);
        class2_right_Subband2=SubBand_2_train_data(:,:,right_data_set);
        %For subband3
        class1_left_Subband3=SubBand_3_train_data(:,:,left_data_set);
        class2_right_Subband3=SubBand_3_train_data(:,:,right_data_set);

    %% CSP start here for Fullband
    %Prepare data for CSP
    % for left hand movement
    [s1 s2 s3]=size(class1_left_FullBand);
    sum_left_FullBand=zeros(ch,s2*s3);  
    for i=1:sum_left_train
        llb=((i-1)*ts)+1;
        uub=llb+ts-1;
        sum_left_FullBand(:,llb:uub)=class1_left_FullBand(:,:,i); % sum_left_FullBand=Class 1 Data in Channels*Observations
        
    end
   
    %for right foot movement
    sum_right_FullBand=zeros(ch,s2*s3);
    for i=1:sum_right_train
        l1b=((i-1)*ts)+1;
        u1b=l1b+ts-1;
        sum_right_FullBand(:,l1b:u1b)=class2_right_FullBand(:,:,i);  % sum_right_FullBand=Class 2 Data in Channels*Observations
         
    end
   
    
    [PTranspose] = CSP(sum_left_FullBand,sum_right_FullBand); %call CSP function and get n-dimensional filter by sorting  
    
        %% Create projected matrix Train by P=Wx for FullBand
        spatia_filter_pair=2; % spatial filter pair
        No_of_feature=spatia_filter_pair*2;
        PTranspose=PTranspose(1:No_of_feature,:);  % Select first 8 rows (2m dimensional spatial filter.. m=4)
        sum_train=sum(trainSet);  % No of train
        [tr1 tr2 tr3]=size(FullBand_train_data);
        
        
        FullBand_train_feature=zeros(No_of_feature,sum_train);
        for iCh=1:No_of_feature
            for iTr=1:sum_train
                infea=FullBand_train_data(:,:,iTr);
                prjfea=PTranspose(iCh,:)*infea;   % Filtering
                FullBand_train_feature(iCh,iTr)=log(var(prjfea));  % Log Variance
            end
        end
          
        FullBand_train_feature=FullBand_train_feature';  % FullBand Training Feature vector
        
    %% CSP start here for Subband 1
    %Prepare data for CSP
    % for left hand movement
  [s1 s2 s3]=size(class1_left_Subband1);
    sum_left_SubBand1=zeros(ch,s2*s3);
    for i=1:sum_left_train
        llb=((i-1)*ts)+1;
        uub=llb+ts-1;
        sum_left_SubBand1(:,llb:uub)=class1_left_Subband1(:,:,i);  % sum_left_SubBand1=Class 1 Data in Channels*Observations
        
    end
   
    %for right hand movement
    sum_right_SubBand1=zeros(ch,s2*s3);
    for i=1:sum_right_train
        l1b=((i-1)*ts)+1;
        u1b=l1b+ts-1;
        sum_right_SubBand1(:,l1b:u1b)=class2_right_Subband1(:,:,i);  % sum_right_SubBand1=Class 2 Data in Channels*Observations
         
    end
   
    
    [PTranspose1] = CSP(sum_left_SubBand1,sum_right_SubBand1); %call CSP function and get n-dimensional filter by sorting   
     %% Create projected matrix Train by P=Wx for SubBand 1
        PTranspose1=PTranspose1(1:No_of_feature,:);  % Select first 8 rows (2m dimensional spatial filter.. m=4)
        sum_train1=sum(trainSet);  % No of train
        [tr1 tr2 tr3]=size(SubBand_1_train_data);
        
        
        SubBand1_train_feature=zeros(No_of_feature,sum_train1);
        for iCh=1:No_of_feature
            for iTr=1:sum_train1
                infea=SubBand_1_train_data(:,:,iTr);
                prjfea=PTranspose1(iCh,:)*infea;  % Filtering
                SubBand1_train_feature(iCh,iTr)=log(var(prjfea));   % Log Variance
            end
        end
          
        SubBand1_train_feature=SubBand1_train_feature';  % SubBand 1 Training Feature vector
        
        
    %% CSP start here for Subband 2
    %Prepare data for CSP
    % for left hand movement
    [s1 s2 s3]=size(class1_left_Subband2);
    sum_left_SubBand2=zeros(ch,s2*s3);
    for i=1:sum_left_train
        llb=((i-1)*ts)+1;
        uub=llb+ts-1;
        sum_left_SubBand2(:,llb:uub)=class1_left_Subband2(:,:,i);   % sum_left_SubBand2=Class 1 Data in Channels*Observations
        
    end
   
    %for right hand movement
    sum_right_SubBand3=zeros(ch,s2*s3);
    for i=1:sum_right_train
        l1b=((i-1)*ts)+1;
        u1b=l1b+ts-1;
        sum_right_SubBand3(:,l1b:u1b)=class2_right_Subband2(:,:,i);   % sum_right_SubBand2=Class 2 Data in Channels*Observations
         
    end
   
    
    [PTranspose2] = CSP(sum_left_SubBand2,sum_right_SubBand3); %call CSP function and get n-dimensional filter by sorting     
    
     %% Create projected matrix Train by P=Wx for SubBand 2
     PTranspose2=PTranspose2(1:No_of_feature,:);  % Select first 8 rows (2m dimensional spatial filter.. m=4)
        sum_train2=sum(trainSet);  % No of train
        [tr1 tr2 tr3]=size(SubBand_2_train_data);
      
        
        SubBand2_train_feature=zeros(No_of_feature,sum_train2);
        for iCh=1:No_of_feature
            for iTr=1:sum_train2
                infea=SubBand_2_train_data(:,:,iTr);
                prjfea=PTranspose2(iCh,:)*infea;  % Filtering
                SubBand2_train_feature(iCh,iTr)=log(var(prjfea));  % Log Variance
            end
        end
          
        SubBand2_train_feature=SubBand2_train_feature';  % SubBand 2 Training Feature vector
        
        
    %% CSP start here for Subband 3
    %Prepare data for CSP
    % for left hand movement
     [s1 s2 s3]=size(class1_left_Subband3);
    sum_left_SubBand3=zeros(ch,s2*s3);
    for i=1:sum_left_train
        llb=((i-1)*ts)+1;
        uub=llb+ts-1;
        sum_left_SubBand3(:,llb:uub)=class1_left_Subband3(:,:,i);   % sum_left_SubBand3=Class 1 Data in Channels*Observations
        
    end
   
    %for right hand movement
    sum_right_SubBand3=zeros(ch,s2*s3);
    for i=1:sum_right_train
        l1b=((i-1)*ts)+1;
        u1b=l1b+ts-1;
        sum_right_SubBand3(:,l1b:u1b)=class2_right_Subband3(:,:,i);   % sum_right_SubBand3=Class 2 Data in Channels*Observations
         
    end
   
    
    [PTranspose3] = CSP(sum_left_SubBand3,sum_right_SubBand3); %call CSP function and get n-dimensional filter by sorting      
    
     %% Create projected matrix Train by P=Wx for SubBand 3
         PTranspose3=PTranspose3(1:No_of_feature,:);  % Select first 8 rows (2m dimensional spatial filter.. m=4)
        sum_train3=sum(trainSet);  % No of train
        [tr1 tr2 tr3]=size(SubBand_3_train_data);
        
        
        SubBand3_train_feature=zeros(No_of_feature,sum_train3);
        for iCh=1:No_of_feature
            for iTr=1:sum_train3
                infea=SubBand_3_train_data(:,:,iTr);
                prjfea=PTranspose3(iCh,:)*infea;  % Filtering
                SubBand3_train_feature(iCh,iTr)=log(var(prjfea));  % Log Variance
            end
        end
          
        SubBand3_train_feature=SubBand3_train_feature';  % SubBand 3 Training Feature vector
        
        %Concatenate Fullband_Feature,SubBand1_Feature,SubBand2_Feature,SubBand3_Feature
        %dataset= horzcat(FullBand_feature,SubBand1_feature,SubBand2_feature,SubBand3_feature);
         classtrain= horzcat(FullBand_train_feature,SubBand1_train_feature,SubBand2_train_feature,SubBand3_train_feature);

         
         
         %% Create projected matrix Test by P=Wx
        
        %For FullBand
        test_data=Fullband_signal(:,:,testSet);  % Test Data
        sum_test=sum(testSet);   % No of test
        [te1 te2 te3]=size(test_data);
        
         FullBand_test_feature=zeros(No_of_feature,sum_test);
        for iCh=1:No_of_feature
            for iTr=1:sum_test
                infea=test_data(:,:,iTr);
                prjfea=PTranspose(iCh,:)*infea;  % Filtering
                FullBand_test_feature(iCh,iTr)=log(var(prjfea));  % Log Variance
            end
        end
          
       FullBand_test_feature=FullBand_test_feature';  % FullBand Testing Feature vector
        %% For Subband 1
        test_data1=Subband1_signal(:,:,testSet);  % Test Data
        sum_test1=sum(testSet);   % No of test
        [te1 te2 te3]=size(test_data1);
        
         SubBand1_test_feature=zeros(No_of_feature,sum_test1);
        for iCh=1:No_of_feature
            for iTr=1:sum_test1
                infea=test_data1(:,:,iTr);
                prjfea=PTranspose1(iCh,:)*infea;
                SubBand1_test_feature(iCh,iTr)=log(var(prjfea));
            end
        end
          
       SubBand1_test_feature=SubBand1_test_feature';  % SubBand 1 Testing Feature vector
       
           %% For Subband 2
        test_data2=Subband2_signal(:,:,testSet);  % Test Data
        sum_test2=sum(testSet);  % No of test
        [te1 te2 te3]=size(test_data2);
        
         SubBand2_test_feature=zeros(No_of_feature,sum_test2);
        for iCh=1:No_of_feature
            for iTr=1:sum_test2
                infea=test_data2(:,:,iTr);
                prjfea=PTranspose2(iCh,:)*infea;
                SubBand2_test_feature(iCh,iTr)=log(var(prjfea));
            end
        end
          
       SubBand2_test_feature=SubBand2_test_feature';  % SubBand 2 Testing Feature vector
              %% For Subband 3
        test_data3=Subband3_signal(:,:,testSet);  % Test Data
        sum_test3=sum(testSet);   % No of test
        [te1 te2 te3]=size(test_data3);
        
         SubBand3_test_feature=zeros(No_of_feature,sum_test3);
        for iCh=1:No_of_feature
            for iTr=1:sum_test3
                infea=test_data3(:,:,iTr);
                prjfea=PTranspose3(iCh,:)*infea;
                SubBand3_test_feature(iCh,iTr)=log(var(prjfea));
            end
        end
          
       SubBand3_test_feature=SubBand3_test_feature';  % SubBand 3 Testing Feature vector
       
       % Concatenate FullBand_test_feature,SubBand1_test_feature,SubBand2_test_feature,SubBand3_test_feature
       classtest= horzcat(FullBand_test_feature,SubBand1_test_feature,SubBand2_test_feature,SubBand3_test_feature);

       
        %% SVM Classifier
        fitsvm = fitcsvm(classtrain(:,:),groups_data_train,'KernelFunction','rbf');
        [TestResult,Score] = predict(fitsvm , classtest(:,:));
        fitacc(qq) = sum(groups_data_test == TestResult) *100/ numel(groups_data_test);  % store each fold result
  
         %% LDA Classifier 
        linclass = fitcdiscr(classtrain(:,:),groups_data_train);
        [label,Score] = predict(linclass , classtest(:,:));
        lda_acc1(qq) = sum(groups_data_test == label)*100 / numel(groups_data_test);   % store each fold result
        
%% ANN classification
Train_Class_label(1,1:112)=ones();
Train_Class_label(1,113:224)=zeros();
Train_Class_label(2,1:112)=zeros();
Train_Class_label(2,113:224)=ones();

Test_Class_Label(1,1:28)=ones();
Test_Class_Label(1,29:56)=zeros();

Test_Class_Label(2,1:28)=zeros();
Test_Class_Label(2,29:56)=ones();


 %Setup Division of Data for Training, Validation, Testing
% net.divideparam.trainRatio= 70/100;
% net.divideparam.valRatio= 15/100;
% net.divideparam.testRatio= 15/100;

classtrain_for_ANN=classtrain';
 net = feedforwardnet(10,'trainrp'); %high acuracy than patternnet
%  net = patternnet(10,'trainrp'); %low accuracy than feedforwardnet
[net, tr]= train(net,classtrain_for_ANN(:,:),Train_Class_label);
%nntraintool('close');
 %view(net)
%network outputs. Test the network
classtest=classtest';
% outputs  = net(classtrain_for_ANN(:,tr.testInd));
outputs  = net(classtest(:,:));
% performance  = perform(net,Class_label,outputs );


[Ann_c(qq),cm] = confusion(Test_Class_Label,outputs);


end 
   %%
   svmaccu(ii)=sum(fitacc)/no_of_fold;     %Average accuracy of Cross_validation
   LDAaccu(ii)=sum(lda_acc1)/no_of_fold;  
   avg_acc=sum(Ann_c)/no_of_fold;
    
   ANN_Acc(ii)=100*(1-avg_acc);
 
   
end
%% Display Result 
disp('Classification Result using crossValidation model(KFold)');
fprintf('NO of Total Fold is: %d\n',no_of_fold);
fprintf('Total No of Train Data(each fold): %d\nTotal No of Test  Data(each fold): %d\n\n',sum_train,sum_test);


ANN_Final_Acc=sum(ANN_Acc)/iteration;     % 100 Average accuracy 
All_channel_accuray_ANN(all_channel)=ANN_Final_Acc;

SVM_Final_Acc=sum(svmaccu)/iteration;     %Average accuracy of Cross_validation
All_channel_accuray_SVM(all_channel)=SVM_Final_Acc;

LDA_Final_Acc=sum(LDAaccu)/iteration;     %Average accuracy of Cross_validation
All_channel_accuray_LDA(all_channel)=LDA_Final_Acc;

clearvars -except All_channel_accuray_ANN All_channel_accuray_SVM All_channel_accuray_LDA
clc;
close all;
end

writematrix(All_channel_accuray_ANN,'ANN_ay.xlsx');
writematrix(All_channel_accuray_SVM,'SVM_ay.xlsx');
writematrix(All_channel_accuray_LDA,'LDA_ay.xlsx');
